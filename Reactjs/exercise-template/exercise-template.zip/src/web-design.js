import React from 'react'

export default function WebDesign() {
	return (
		<>
			<h1>Web design</h1>
		</>
	)
}