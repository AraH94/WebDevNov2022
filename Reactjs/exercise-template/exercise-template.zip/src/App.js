import Header from './components/Header'
import Footer from './components/Footer';
import Main from './Main';

import {
	BrowserRouter,
	Route,
	Routes
} from 'react-router-dom'

import Layout from './components/layout';
import Project1 from './components/pages/project1';
import Project2 from './components/pages/project2';
import Project3 from './components/pages/project3';
import Project4 from './components/pages/project4';

import Programming from './programming';
import WebDesign from './web-design';

function App() {
	return (
		<>
			<BrowserRouter>
				<Header />
				<Routes>
					<Route path="/" element={<Main />} />
					<Route path="/web-design" element={<WebDesign />} />
					<Route path="/programming" element={<Programming />} />
					
					<Route path="/project1" element={<Project1 />} />
					<Route path="/Project2" element={<Project2 />} />
					<Route path="/Project3" element={<Project3 />} />
					<Route path="/Project4" element={<Project4 />} />
				</Routes>
				<Footer />
			</BrowserRouter>

		</>
	)
}

export default App