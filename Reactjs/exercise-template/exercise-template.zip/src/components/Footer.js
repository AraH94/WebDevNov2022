export default function Footer(){
	return(
		<p className="bg-dark text-light text-center footer">&copy; Copyright</p>
	)
}