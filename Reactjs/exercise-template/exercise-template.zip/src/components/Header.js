import NavigationHeader from "./Header/NavigationHeader";

export default function Header(){
	return(
		<NavigationHeader/>
	)
}